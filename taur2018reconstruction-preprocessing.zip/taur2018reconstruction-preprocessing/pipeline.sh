#!/usr/bin/env bash

python convert_to_otu_table.py
python filter.py
python get_top_otus.py 50
python make_event_table.py 50

rm taur-otu-table-filtered.csv
mv taur-otu-table-top50OTUs.csv taur-otu-table.csv
